Robert Lagomarsino
An Vu
Databases
Final Project
======================================================================================
                          INSTALLING THE APPLICATION
======================================================================================

1. Unzip the files attached. Place them in a folder called database-project.
2. Paste the database-project folder into the www directory of wamp.
3. Start up wamp.
4. Open a web browser
5. Go to http://localhost/database-project.

NOTE: If you have problems running the application, please email rwl251@nyu.edu or
anvu94@hotmail.com.

What we did was have a folder in the www folder and then created a virtual host for it by following the steps as described on this website: http://ronangelo.com/how-to-create-a-project-or-virtual-host-with-wamp/.

Everything is in localhost, it's just in its own folder.
